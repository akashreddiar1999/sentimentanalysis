from flask import Flask,render_template,request,url_for
from flask_bootstrap import Bootstrap 
from flask_uploads import UploadSet,configure_uploads,IMAGES,DATA,ALL
from flask_sqlalchemy import SQLAlchemy 
import matplotlib.pyplot as plt
from werkzeug import secure_filename
import os
import datetime
import time
from bs4 import BeautifulSoup  
import re
import nltk
from nltk.corpus import stopwords 
from nltk.stem.porter import PorterStemmer
from nltk.stem import SnowballStemmer, WordNetLemmatizer
from nltk import sent_tokenize, word_tokenize, pos_tag

import logging
from gensim.models import word2vec
from gensim.models import Word2Vec
from gensim.models.keyedvectors import KeyedVectors

# EDA Packages
import pandas as pd 
import numpy as np 

# ML Packages
from sklearn import model_selection
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import BernoulliNB, MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics
from sklearn.metrics import roc_auc_score,accuracy_score
from sklearn.metrics import f1_score
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import Pipeline






app = Flask(__name__)
Bootstrap(app)
db = SQLAlchemy(app)

# Configuration for File Uploads
files = UploadSet('files',ALL)
app.config['UPLOADED_FILES_DEST'] = 'static'
configure_uploads(app,files)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///static/filestorage.db'


# Saving Data To Database Storage
class FileContents(db.Model):
        id = db.Column(db.Integer,primary_key=True)
        name = db.Column(db.String(300))
        modeldata = db.Column(db.String(300))
        data = db.Column(db.LargeBinary)


@app.route('/')
def index():
        return render_template('index.html')

# Route for our Processing and Details Page
@app.route('/dataupload',methods=['GET','POST'])

def dataupload():
        if request.method == 'POST' and 'csv_data' in request.files:
                file = request.files['csv_data']
                filename = secure_filename(file.filename)
                file.save(os.path.join('static',filename))
                fullfile = os.path.join('static',filename)

                # For Time
                date = str(datetime.datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S"))

                # EDA function
                df = pd.read_csv(os.path.join('static',filename))
                df=df[['Product Name','Brand Name','Price','Rating','Reviews','Review Votes']]
                df.head()
                plt.figure(figsize=(12,8))
                df['Rating'].value_counts().sort_index().plot(kind='bar')
                #df.to_html('predictions.html')
                plt.title('Distribution of Rating')
                plt.xlabel('Rating')
                plt.ylabel('Count')
                plt.savefig('C:/Users/Aakash/AppData/Local/Programs/Python/Python37/data analysis/static/images/plot.png')
                brands = df["Brand Name"].value_counts()
                # brands.count()
                plt.figure(figsize=(12,8))
                brands[:20].plot(kind='bar')
                plt.title("Number of Reviews for Top 20 Brands")
                plt.savefig('C:/Users/Aakash/AppData/Local/Programs/Python/Python37/data analysis/static/images/plot2.png')
                review_length = df["Reviews"].dropna().map(lambda x: len(x))
                plt.figure(figsize=(12,8))
                review_length.loc[review_length < 1500].hist()
                plt.title("Distribution of Review Length")
                plt.xlabel('Review length (Number of character)')
                plt.ylabel('Count')
                plt.savefig('C:/Users/Aakash/AppData/Local/Programs/Python/Python37/data analysis/static/images/plot3.png')
                import numpy as np
                df = df.sample(frac=0.1, random_state=0) #uncomment to use full set of data
                #drop missing values
                df.dropna(inplace=True)
                # Remove any 'neutral' ratings equal to 3
                df = df[df['Rating'] != 3]
                # Encode 4s and 5s as 1 (positive sentiment) and 1s and 2s as 0 (negative sentiment)
                df['Sentiment'] = np.where(df['Rating'] > 3, 1, 0)
                RAN_STATE=42
                X_train, X_test, y_train, y_test = train_test_split(df['Reviews'], df['Sentiment'], \
                                                                    test_size=0.1, random_state=RAN_STATE)
                #print('Load %d training examples and %d validation examples. \n' %(X_train.shape[0],X_test.shape[0]))
                #print('Show a review in the training set : \n',X_train.iloc[10])
                def cleanText(raw_text, remove_stopwords=False, stemming=False, split_text=False, \
                              ):
                        text = BeautifulSoup(raw_text, 'lxml').get_text()  #remove html
                        letters_only = re.sub("[^a-zA-Z]", " ", text)  # remove non-character
                        words = letters_only.lower().split() # convert to lower case
                        if remove_stopwords: # remove stopword
                                stops = set(stopwords.words("english"))
                                words = [w for w in words if not w in stops]
                        if stemming==True: # stemming
                        #stemmer = PorterStemmer()
                                stemmer = SnowballStemmer('english')
                                words = [stemmer.stem(w) for w in words]
                        if split_text==True:  # split text
                                return (words)
                        return( " ".join(words))
                X_train_cleaned = []
                X_test_cleaned = []
                for d in X_train:
                        X_train_cleaned.append(cleanText(d))
                #print("Show a cleaned review in the training set:\n",X_train_cleaned[10])
                for d in X_test:
                        X_test_cleaned.append(cleanText(d))
                countVect = CountVectorizer()
                X_train_countVect = countVect.fit_transform(X_train_cleaned)
                #print("Number of features : %d \n" %len(countVect.get_feature_names())) #6378
                #print("Show some feature names : \n", countVect.get_feature_names()[::1000])
                # Train MultinomialNB classifier
                mnb = MultinomialNB()
                mnb.fit(X_train_countVect, y_train)
                predictions = mnb.predict(countVect.transform(X_test_cleaned))
                MNacu="{:.4f}".format(accuracy_score(y_test,predictions))
                MNscore="{:.4f}".format(roc_auc_score(y_test, predictions))
                metri=f1_score(y_test, predictions)
                matri=metrics.confusion_matrix(y_test, predictions)

                
                #Logistic Regression
                tfidf = TfidfVectorizer(min_df=5) #minimum document frequency of 5
                X_train_tfidf = tfidf.fit_transform(X_train)
                #print("Number of features : %d \n" %len(tfidf.get_feature_names())) #1722
                #print("Show some feature names : \n", tfidf.get_feature_names()[::1000])
                lr = LogisticRegression()
                lr.fit(X_train_tfidf, y_train)
                feature_names = np.array(tfidf.get_feature_names())
                sorted_coef_index = lr.coef_[0].argsort()
                features="\n{}".format(feature_names[sorted_coef_index[:10]])
                top="\n{}".format(feature_names[sorted_coef_index[:-11:-1]])
                predictions2 = lr.predict(tfidf.transform(X_test_cleaned))
                LRacu="{:.4f}".format(accuracy_score(y_test,predictions2))
                LRscore="{:.4f}".format(roc_auc_score(y_test, predictions2))
                LRmetri=f1_score(y_test, predictions2)
                LRmatri=metrics.confusion_matrix(y_test, predictions2)
                fig = plt.figure(figsize=(8, 8), edgecolor = 'black')
                plt.title('Comparing the 2 models')
                barWidth = 0.25
                time1 = [0.1340, 1.3089,] #logistic regression, SVM, XGB
                f1_score1 = [0.94, 0.95]
                accuracy = [0.91, 0.93]
                r1 = np.arange(len(time1))
                r2 = [x + barWidth for x in r1]
                plt.bar(r1, f1_score1, width=barWidth, label='F1 Score')
                plt.bar(r2, accuracy, width=barWidth, label='Accuracy')
                plt.xticks([r + barWidth for r in range(len(time1))], ['MultinomialNB classifier','Logistic Regression'])
                plt.rc('xtick',labelsize=20)
                plt.rc('ytick',labelsize=20)
                plt.legend(fontsize=20)
                plt.savefig('C:/Users/Aakash/AppData/Local/Programs/Python/Python37/data analysis/static/images/graph.png')
                
            
        return render_template('details.html',filename=filename,date=date,
                url='static/images/plot.png',
                url2='static/images/plot2.png',
                url3='static/images/plot3.png',
                url4='static/images/graph.png',
                url5='static/images/samsung.png',
                url6='static/images/Apple.png',
                url7='static/images/Nokia.png',
                url8='static/images/Sony.png',
                M_N=MNacu,
                score=MNscore,
                metrics=metri,
                matrix=matri,
                train=X_train.iloc[10],
                no=len(tfidf.get_feature_names()),
                names=countVect.get_feature_names()[::1000],
                fea=features,
                top10=top,
                LR1=LRacu,
                LR2=LRscore,
                LR3=LRmetri,
                LR4=LRmatri,
                df_head=df.head(),
                df_size=df.size,
                df_columns=df.columns,
                df_len=len(df),df_des=df.describe(),df_brand=len(list(set(df['Brand Name']))),
                df_pos=df[df['Rating']>3]["Reviews"].count()/len(df)*100,
                df_neg=df[df['Rating']<3]["Reviews"].count()/len(df)*100,
                df_neu=df[df['Rating']==3]["Reviews"].count()/len(df)*100,
                df_uni=len(list(set(df['Product Name']))))


if __name__ == '__main__':
        app.run(debug=True)



